echo off
cls
echo                         THE ALL-NEW MISADVENTURES OF
echo                                DANGEROUS DAVE
echo                       Episode 1:  DAVE'S RISKY RESCUE
echo *****************************************************************************
echo *                          Quick Start Information                          *
echo *                                                                           *
echo * Recommend installing game in separate directory on hard drive.            *
echo *                                                                           *
echo * Free memory required to play:  605K (w/ sound) or 570K (w/out sound)      *
echo *   (Boot a DOS system disk or remove AUTOEXEC.BAT & CONFIG.SYS for memory) *
echo *                                                                           *
echo * Game graphics are EGA (supported on EGA, VGA and SVGA cards)              *
echo *                                                                           *
echo * Sound fx supported on:        PC speaker, Sound Blaster,                  *
echo *                               Ad Lib, and Disney Sound Source             *
echo *                                                                           *
echo * Once playing game, PRESS [F1] KEY FOR MORE HELP AND INFORMATION           *
echo *                                                                           *
echo * Your goal:  Rescue your little brother Delbert from the evil Dr. Nemesis! *
echo *                                                                           *
echo *        For Technical Support, call 1-800-831-2694 or 1-318-221-8718       *
echo *                                                                           *
echo *****************************************************************************
pause
dave %1 %2 %3 %4 %5 %6 %7 %8 %9^Z